import 'package:flutter/foundation.dart';

class Contact {
  String firstName;
  String lastName;
  String phoneNo;
  String email;

  Contact({
    @required this.firstName,
    @required this.lastName,
    @required this.phoneNo,
    this.email,
  });
}
