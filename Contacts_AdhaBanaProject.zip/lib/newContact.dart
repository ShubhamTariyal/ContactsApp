import 'package:flutter/material.dart';

class NewContact extends StatefulWidget {
  @override
  _NewContactState createState() => _NewContactState();
}

class _NewContactState extends State<NewContact> {
  final firstNameTxtController = TextEditingController();
  final lastNameTxtController = TextEditingController();
  final phoneNoTxtController = TextEditingController();
  final emailTxtController = TextEditingController();

  FocusNode lastNameFocusNode = new FocusNode();
  FocusNode phoneNoFocusNode = new FocusNode();
  FocusNode emailFocusNode = new FocusNode();

  void _addNewContact() {
    
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Add Contact',
          ),
        ),
        body: Container(
          color: Colors.red,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "First Name",
                style: TextStyle(fontSize: 18),
              ),
              TextField(
                controller: firstNameTxtController,
                textInputAction: TextInputAction.next,
                onSubmitted: (_) {
                  FocusScope.of(context).requestFocus(lastNameFocusNode);
                },
              ),
              Text(
                "Last Name",
                style: TextStyle(fontSize: 18),
              ),
              TextField(
                controller: lastNameTxtController,
                textInputAction: TextInputAction.next,
                focusNode: lastNameFocusNode,
                onSubmitted: (_) {
                  FocusScope.of(context).requestFocus(phoneNoFocusNode);
                },
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
              ),
              Text(
                "Phone No.",
                style: TextStyle(fontSize: 18),
              ),
              TextField(
                controller: phoneNoTxtController,
                textInputAction: TextInputAction.next,
                focusNode: phoneNoFocusNode,
                onSubmitted: (_) {
                  FocusScope.of(context).requestFocus(emailFocusNode);
                },
              ),
              Text(
                "Email: ",
                style: TextStyle(fontSize: 18),
              ),
              TextField(
                controller: emailTxtController,
                textInputAction: TextInputAction.done,
                focusNode: emailFocusNode,
                onSubmitted: (_) => _addNewContact(),
              ),
              Container(
                margin: EdgeInsets.only(
                  top: 30,
                ),
                height: 40,
                width: double.infinity,
                child: RaisedButton(
                  child: Text(
                    'Done',
                    style: TextStyle(fontSize: 18),
                  ),
                  onPressed: _addNewContact,
                  color: Colors.blue,
                  textColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
