import 'package:flutter/material.dart';

class InputText extends StatelessWidget {
  InputText({
    @required this.title,
    @required this.txtController,
    this.next = true,
    this.callback,
    this.widgetFocusNode,
    this.targetFocusNode,
  });

  final String title;
  final bool next;

  final TextEditingController txtController;
  final FocusNode widgetFocusNode;
  final FocusNode targetFocusNode;

  final Function callback;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 18),
        ),
        TextField(
          controller: txtController,
          textInputAction: next ? TextInputAction.next : TextInputAction.done,
          focusNode: widgetFocusNode,
          onSubmitted: (_) {
            if(targetFocusNode != null)
            FocusScope.of(context).requestFocus(targetFocusNode);
            if (callback is Function) {
              callback();
            }
          },
        ),
      ],
    );
  }
}
