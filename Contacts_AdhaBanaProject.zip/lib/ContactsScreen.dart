import 'dart:ui';

import 'package:flutter/material.dart';

import 'newContact.dart';
import 'Contact.dart';

class Contacts extends StatefulWidget {
  @override
  _ContactsState createState() => _ContactsState();
}

class _ContactsState extends State<Contacts> {
  List<Contact> contacts = [
    Contact(firstName: 'Asish', lastName: 'Kumar', phoneNo: '1110111011'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Keshav', lastName: 'Sharma', phoneNo: '9310342911'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Parivarik', lastName: 'Sanskar', phoneNo: '8980100011'),
    Contact(firstName: 'Raghav', lastName: 'Trivedi', phoneNo: '8811011011'),
    Contact(firstName: 'Sikandar', lastName: 'Singh', phoneNo: '7215131011'),
  ];

  void _addContact(cntxt) {
    // take input and add to contacts list
    // contacts.add(item);

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NewContact()),
    );

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Contacts'),
          actions: [
            Container(
              margin: EdgeInsets.only(right: 20),
              color: Colors.lightBlue,
              child: IconButton(
                onPressed: () {
                  _addContact(context);
                },
                icon: Icon(Icons.add),
              ),
            ),
          ],
        ),
        body: ListView.builder(
          itemBuilder: (cntx, index) {
            return Card(
              elevation: 2,
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage('assets/images/download.png'),
                  radius: 25,
                ),
                title: Text(
                  '${contacts[index].firstName} ${contacts[index].lastName}',
                  style: TextStyle(
                    fontSize: 18,
                  ),
                ),
                subtitle: Text(
                  '${contacts[index].phoneNo}',
                  // style: TextStyle(color: Colors.blue),
                ),
                onTap: () {
                  // setState(() {

                  // });
                },
              ),
              // child: Row(
              //   children: [
              //     Image(
              //       image: AssetImage('assests/images/download.png'),
              //       width: 100,
              //     ),
              //     Text(
              //       '${contacts[index].firstName} ${contacts[index].lastName}',
              //       style: TextStyle(fontSize: 18, color: Colors.grey),
              //     ),
              //   ],
              // ),
            );
          },
          itemCount: contacts.length,
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () => _addContact(context),
        ),
      ),
    );
  }
}
